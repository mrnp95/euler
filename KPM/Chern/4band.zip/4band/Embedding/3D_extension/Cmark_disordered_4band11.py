import kwant 
import numpy as np
import scipy
import scipy.sparse.linalg as sla
import scipy.linalg as la
from numpy import sqrt
import tinyarray as ta
import matplotlib.pyplot as plt
import functools as ft
import mirror_chern_original as ch
from kpm_funcs import position_operator

# Default settings

lat_const = 1  # lattice constant of square lattice (unit: nm)
t0 = 1.00    # hoppings (unit: eV)
t1 = 1.00
m = 1.00
delta = 0.50
lambdaCh = 1.00


epsA = 0.5
epsB = -0.5
epsC = -0.5
epsD = 0.5


d  = 1.0    # standard deviation in Gaussian disorder (unit: eV)
L = 15 # size of the system (in each dimension)
averaging = 1 # number of disorder realisations
disorders = [0.00, 0.01, 0.1, 0.3, 0.5, 0.8, 1.0, 1.2, 1.5, 1.8, 2.0, 2.5, 3.0, 4.0, 5.0]
lambda_s = [1.00, 0.50, 0.25, 0.00]

# Domains of cond function for later

N_bins = 100 # Bins for energies in the estimator
N_binsT = 500 # Bins for temperature
T_min = 0.01 
T_max = 5.00
T = np.linspace(T_min, T_max, N_binsT)


##########
# BUILD  #
##########

def make_system(type_4band = 'monolayer'):
    
    Bravais_vector = [(lat_const, 0, 0), 
                        (0,  lat_const, 0),
			(0 , 0,  lat_const)] # Bravais vectors
    Bottom_Lat_pos = [(0, 0, 0), (0, 0, 0), (0, 0, 0), (0, 0, 0)]    # The position of sublattice atoms in Bottom layer  
    Bottom_lat = kwant.lattice.general(Bravais_vector, Bottom_Lat_pos, norbs=1)
    B_sub_A, B_sub_B, B_sub_C, B_sub_D = Bottom_lat.sublattices 
    
    sym = kwant.TranslationalSymmetry(Bravais_vector[0], Bravais_vector[1])
    bulk = kwant.Builder(sym)

    # define hoppings and on-site potentials
    for z in range(0, 5):
        for x in range(-int(L/2), int(L/2)):
            for y in range(-int(L/2), int(L/2)):
                bulk[B_sub_A(x,y,z)] = epsA*0+delta+np.random.normal(0, d, 1)
                bulk[B_sub_B(x,y,z)] = epsB*0-delta+np.random.normal(0, d, 1)
                bulk[B_sub_C(x,y,z)] = epsC*0-delta+np.random.normal(0, d, 1)
                bulk[B_sub_D(x,y,z)] = epsD*0+delta+np.random.normal(0, d, 1)
				
    bulk[kwant.builder.HoppingKind((0,1,0), B_sub_A,B_sub_A)] = t0
    bulk[kwant.builder.HoppingKind((0,-1,0), B_sub_A,B_sub_A)] = -t0
    bulk[kwant.builder.HoppingKind((0,1,0), B_sub_C,B_sub_C)] = t0
    bulk[kwant.builder.HoppingKind((0,-1,0), B_sub_C,B_sub_C)] = -t0
    
    bulk[kwant.builder.HoppingKind((0,1,0), B_sub_B,B_sub_B)] = -t0
    bulk[kwant.builder.HoppingKind((0,-1,0), B_sub_B,B_sub_B)] = t0
    bulk[kwant.builder.HoppingKind((0,1,0), B_sub_D,B_sub_D)] = -t0
    bulk[kwant.builder.HoppingKind((0,-1,0), B_sub_D,B_sub_D)] = t0 
   
    bulk[kwant.builder.HoppingKind((1,0,0), B_sub_A,B_sub_B)] = t0
    bulk[kwant.builder.HoppingKind((-1,0,0), B_sub_A,B_sub_B)] = -t0
    
    bulk[kwant.builder.HoppingKind((1,0,0), B_sub_C,B_sub_D)] = t0
    bulk[kwant.builder.HoppingKind((-1,0,0), B_sub_C,B_sub_D)] = -t0
  
    bulk[kwant.builder.HoppingKind((0,0,0), B_sub_A,B_sub_D)] = m
    bulk[kwant.builder.HoppingKind((0,0,0), B_sub_B,B_sub_C)] = -m

    bulk[kwant.builder.HoppingKind((0,1,0), B_sub_A,B_sub_D)] = -t1
    bulk[kwant.builder.HoppingKind((0,-1,0), B_sub_A,B_sub_D)] = -t1
    bulk[kwant.builder.HoppingKind((1,0,0), B_sub_A,B_sub_D)] = -t1
    bulk[kwant.builder.HoppingKind((-1,0,0), B_sub_A,B_sub_D)] = -t1
     
    bulk[kwant.builder.HoppingKind((0,1,0), B_sub_B,B_sub_C)] = t1
    bulk[kwant.builder.HoppingKind((0,-1,0), B_sub_B,B_sub_C)] = t1
    bulk[kwant.builder.HoppingKind((1,0,0), B_sub_B,B_sub_C)] = t1
    bulk[kwant.builder.HoppingKind((-1,0,0), B_sub_B,B_sub_C)] = t1 

        #Embedding hopping 
	
    bulk[kwant.builder.HoppingKind((0,0,1), B_sub_A,B_sub_C)] = -1j*lambdaCh-3/4*1j*lambdaCh
    bulk[kwant.builder.HoppingKind((0,0,-1), B_sub_A,B_sub_C)] = 1j*lambdaCh+3/4*1j*lambdaCh
    bulk[kwant.builder.HoppingKind((0,0,2), B_sub_A,B_sub_C)] = -1j/2*lambdaCh+3/8*1j*lambdaCh
    bulk[kwant.builder.HoppingKind((0,0,-2), B_sub_A,B_sub_C)] = 1j/2*lambdaCh-3/8*1j*lambdaCh
    bulk[kwant.builder.HoppingKind((0,0,1), B_sub_B,B_sub_D)] = -1j*lambdaCh-3/4*1j*lambdaCh
    bulk[kwant.builder.HoppingKind((0,0,-1), B_sub_B,B_sub_D)] = 1j*lambdaCh+3/4*1j*lambdaCh
    bulk[kwant.builder.HoppingKind((0,0,2), B_sub_B,B_sub_D)] = -1j/2*lambdaCh+3/8*1j*lambdaCh
    bulk[kwant.builder.HoppingKind((0,0,-2), B_sub_B,B_sub_D)] = 1j/2*lambdaCh-3/8*1j*lambdaCh


    return bulk

# Different geometries of the finite system

def trunc(site):
    x, y, z = abs(site.pos)
    return abs(x) <= 15 and abs(y) <= 15

def circle(site):
    x, y = site.pos
    r = 30
    return x ** 2 + y ** 2 < r ** 2

# Declare big things coming

for t in lambda_s:
    
    lambdaCh = t

    legend = []
    
    C_final = []

    C_final_std = []

    fig_C, ax_C = plt.subplots()
    
    for d in disorders:
        
        print("lambdaCh = "+str(t)+", d = "+str(d))

        all_energies = []
        all_densities = []
        all_cond_xx_miu = []
        all_cond_xy_miu = []
        all_T = []
        all_cond_xx_T = []
        all_cond_xy_T = []

        C_av = 0
        C_av_std = 0
	
        for av in range(0, averaging):
        
            # Hoppings
            
            epsA = t
            epsB = t
            epsC = t

            syst = kwant.Builder() 
            model = make_system(type_4band = 'monolayer')
            #kwant.plot(model)
            #model = make_syst_topo()
            area_per_site = np.abs(lat_const*lat_const)
            syst.fill(model, trunc, (0, 0, 0));
             
            syst.eradicate_dangling()
            
            # Plot system before running
            
            #kwant.plot(syst);


            fsyst = syst.finalized()

            # Chern markers

            num_vectors = 5
            num_moments = 200
            A = area_per_site*L*L

            C_list = []

            systw = kwant.wraparound.wraparound(syst)   
            fsystw = systw.finalized()
            x, y, z = position_operator(fsystw)

           
            #tags = np.array([[i,j] for i in range(int(-L*0/2), int(L/2)) for j in range(int(-L/2), int(L/2))])
            #tags = np.array([[i,j] for i in [0, -15] for j in [0, 15]])
            tags = np.array([np.hstack([np.random.randint(-int(L/2), high=(int(L/2)), size=2), 0]) for i in range(0, num_vectors)])
            vectors = []
            Cs = 0
            C_all = []
            err = 0
            """
            n = np.array([1, 0, 0])
            M_trf = ft.partial(ch.M_cubic, n=n)
            UM = ch.UM_s(n)
            M = ch.pg_op(fsystw, M_trf, UM)
            print(M)
            """
            for tag in tags:

                where = lambda s: s.tag == tag
                vector_factory = kwant.kpm.LocalVectors(fsyst, where)
                vectors = vector_factory
                #C_list = [ch.mirror_chern(fsyst, x, y, Mz=None, vectors=num_vectors, e_F=0, kpm_params=dict(num_moments=num_moments), params=None, bounds=None, window=window, return_std=False) for window in windows]
            
                C_list = ch.mirror_chern(fsyst, x, y, Mz=None, vectors=vectors, e_F=0, kpm_params=dict(num_moments=num_moments), params=None, bounds=None, window=None, return_std=False)
                C_list = np.array(C_list)
                Cs = np.sum(C_list, axis = 0) / (area_per_site*4)
                print(Cs, tag)
                if np.abs(Cs) > 2: 
                    err += err
                    print('Numerical error!')
                else:
                    C_all.append(Cs)

            #Cs = np.sum(C_list, axis = 0) / vectors.shape[1]
            #Cs = np.sum(C_list, axis = 0)

            C = np.mean(np.array(C_all))
            C_std = np.std(np.array(C_all))
            print('Sampled Local Chern = '+str(C)+', Stdev of Local Chern = '+str(C_std))
            C_av += 1/(averaging - err)*C
            C_av_std += 1/(averaging - err)*C_std

        print('Averaged Local Chern = '+str(C_av))
        C_final.append(np.abs(C_av))
        C_final_std.append(C_av_std)

    ax_C.plot(disorders, C_final)
    ax_C.set_title("Averaged local Chern number |C| as a function of disorder \n ($\lambda_{ch}$ = "+str(round(t, 2))+")", y=1.1)
    ax_C.set_xlabel(r"Disorder strength $\sigma$")
    ax_C.set_ylabel(r"Local Chern number averaged over system")
    ax_C.set_xlim(int(disorders[0]), int(disorders[len(disorders)-1]))
    #fig_C.legend(legend, loc='upper right', bbox_to_anchor=(0.90, 0.8))       
    fig_C.tight_layout()
    save_fig_to = './'
    fig_C.savefig(save_fig_to + "Marking_4band11_lambdaCh_"+str(t)+".png", bbox_inches = 'tight', dpi='figure')

    ############
    # SAVING   #
    ############

    file_name = "4band11_Chern_marking_dis_full_"+"_lambdaCh_"+str(t)+"_L_"+str(L)+".dat"
    with open(file_name, "x") as file_fd:
        for i in range(0, len(C_final)):
            file_fd.write(str(disorders[i])+" "+str(C_final[i])+" "+str(C_final_std[i])+"\n")

